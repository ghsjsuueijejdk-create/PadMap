package com.padmap

import android.accessibilityservice.AccessibilityService
import android.os.Build
import android.util.DisplayMetrics
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

class PadService : AccessibilityService() {

    private lateinit var engine: TouchEngine
    private var pkg: String? = null
    private var profile: Profile? = null
    private var editor: Editor? = null
    private val stickOn = BooleanArray(2)
    private val hatOn = BooleanArray(4)

    override fun onServiceConnected() {
        Store.init(this)
        engine = TouchEngine(this)
        if (Build.VERSION.SDK_INT >= 34) {
            try {
                val info = serviceInfo
                info.setMotionEventSources(InputDevice.SOURCE_JOYSTICK)
                serviceInfo = info
            } catch (e: Throwable) {
            }
        }
    }

    private fun screen(): Pair<Float, Float> {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val m = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(m)
        return Pair(m.widthPixels.toFloat(), m.heightPixels.toFloat())
    }

    private fun ignored(p: String): Boolean {
        if (p == "com.android.systemui") return true
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        return imm.enabledInputMethodList.any { it.packageName == p }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val p = e.packageName?.toString() ?: return
        if (ignored(p)) return
        if (p != pkg) {
            releaseEverything()
            pkg = p
            profile = Store.load(p)
        }
        if (Store.pending == p && editor == null) {
            Store.pending = null
            val ed = Editor(this, p) {
                editor = null
                profile = Store.load(p)
            }
            editor = ed
            ed.show()
        }
    }

    private fun releaseEverything() {
        engine.releaseAll()
        stickOn.fill(false)
        hatOn.fill(false)
    }

    override fun onInterrupt() {
        releaseEverything()
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val pr = profile ?: return false
        if (editor != null) return false
        val src = event.source
        val isPad = (src and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
            (src and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
        if (!isPad) return false
        val c = Control.fromKey(event.keyCode) ?: return false
        val cfg = pr.c[c] ?: return false
        if (!cfg.on) return false
        val (w, h) = screen()
        when (event.action) {
            KeyEvent.ACTION_DOWN -> if (event.repeatCount == 0) engine.down(c.ordinal, cfg.x * w, cfg.y * h)
            KeyEvent.ACTION_UP -> engine.up(c.ordinal)
        }
        return true
    }

    // Android 14+: сюда приходят движения стиков.
    override fun onMotionEvent(event: MotionEvent) {
        val pr = profile ?: return
        if (editor != null) return
        if ((event.source and InputDevice.SOURCE_JOYSTICK) == 0) return
        val (w, h) = screen()

        stick(0, Control.LSTICK, pr, w, h,
            event.getAxisValue(MotionEvent.AXIS_X), event.getAxisValue(MotionEvent.AXIS_Y))

        val zx = event.getAxisValue(MotionEvent.AXIS_Z)
        val zy = event.getAxisValue(MotionEvent.AXIS_RZ)
        val rx = event.getAxisValue(MotionEvent.AXIS_RX)
        val ry = event.getAxisValue(MotionEvent.AXIS_RY)
        if (hypot(zx, zy) >= hypot(rx, ry)) stick(1, Control.RSTICK, pr, w, h, zx, zy)
        else stick(1, Control.RSTICK, pr, w, h, rx, ry)

        val hx = event.getAxisValue(MotionEvent.AXIS_HAT_X)
        val hy = event.getAxisValue(MotionEvent.AXIS_HAT_Y)
        hat(0, Control.DUP, pr, w, h, hy < -0.5f)
        hat(1, Control.DDOWN, pr, w, h, hy > 0.5f)
        hat(2, Control.DLEFT, pr, w, h, hx < -0.5f)
        hat(3, Control.DRIGHT, pr, w, h, hx > 0.5f)
    }

    private fun hat(i: Int, c: Control, pr: Profile, w: Float, h: Float, pressed: Boolean) {
        val cfg = pr.c[c] ?: return
        if (!cfg.on) return
        if (pressed && !hatOn[i]) {
            hatOn[i] = true
            engine.down(c.ordinal, cfg.x * w, cfg.y * h)
        } else if (!pressed && hatOn[i]) {
            hatOn[i] = false
            engine.up(c.ordinal)
        }
    }

    private fun stick(i: Int, c: Control, pr: Profile, w: Float, h: Float, ax: Float, ay: Float) {
        val cfg = pr.c[c] ?: return
        if (!cfg.on) return
        val cx = cfg.x * w
        val cy = cfg.y * h
        val r = min(w, h) * Model.STICK_R
        val mag = hypot(ax, ay)
        if (mag > 0.25f) {
            val k = if (mag > 1f) 1f / mag else 1f
            val tx = cx + ax * k * r
            val ty = cy + ay * k * r
            if (!stickOn[i]) {
                stickOn[i] = true
                engine.down(c.ordinal, cx, cy)
            }
            engine.move(c.ordinal, tx, ty)
        } else if (stickOn[i]) {
            stickOn[i] = false
            engine.up(c.ordinal)
        }
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        releaseEverything()
        editor?.close()
        return super.onUnbind(intent)
    }
}
