package com.padmap

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Store.init(this)
        val d = resources.displayMetrics.density
        val pad = (16 * d).toInt()

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, pad, pad, pad)

        fun text(t: String, size: Float = 16f): TextView {
            val v = TextView(this)
            v.text = t
            v.textSize = size
            v.setPadding(0, pad / 2, 0, pad / 2)
            col.addView(v)
            return v
        }

        fun button(t: String, f: () -> Unit) {
            val v = Button(this)
            v.text = t
            v.setOnClickListener { f() }
            col.addView(v)
        }

        text("PadMap", 28f)
        text("Играй в любые игры с геймпадом. Настройка один раз для каждой игры, потом всё включается само.")
        status = text("")
        button("1. Включить службу") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        text("Если пункт серый: Настройки → Приложения → PadMap → ⋮ → «Разрешить ограниченные настройки».", 13f)
        button("2. Настроить игру") { pickGame() }
        button("Мои игры") { myGames() }

        setContentView(ScrollView(this).apply { addView(col) })
    }

    override fun onResume() {
        super.onResume()
        status.text = if (serviceOn()) "Служба включена ✓" else "Служба выключена"
    }

    private fun serviceOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        return s.contains("$packageName/")
    }

    private fun launchEdit(pkg: String) {
        if (!serviceOn()) {
            Toast.makeText(this, "Сначала включи службу", Toast.LENGTH_LONG).show()
            return
        }
        val i = packageManager.getLaunchIntentForPackage(pkg)
        if (i == null) {
            Toast.makeText(this, "Не удалось открыть игру", Toast.LENGTH_LONG).show()
            return
        }
        Store.pending = pkg
        startActivity(i)
    }

    private fun pickGame() {
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(q, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
        AlertDialog.Builder(this)
            .setTitle("Выбери игру")
            .setItems(apps.map { it.second }.toTypedArray()) { _, w -> launchEdit(apps[w].first) }
            .show()
    }

    private fun label(p: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(p, 0)).toString()
    } catch (e: Exception) {
        p
    }

    private fun myGames() {
        val list = Store.saved()
        if (list.isEmpty()) {
            Toast.makeText(this, "Пока нет настроенных игр", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Мои игры")
            .setItems(list.map { label(it) }.toTypedArray()) { _, w ->
                val p = list[w]
                AlertDialog.Builder(this)
                    .setTitle(label(p))
                    .setPositiveButton("Перенастроить") { _, _ -> launchEdit(p) }
                    .setNegativeButton("Удалить") { _, _ -> Store.delete(p) }
                    .setNeutralButton("Закрыть", null)
                    .show()
            }
            .show()
    }
}
