package com.padmap

import android.accessibilityservice.AccessibilityService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager
import kotlin.math.hypot
import kotlin.math.min

class PadService : AccessibilityService() {

    private lateinit var engine: TouchEngine
    private lateinit var fab: Fab
    private var pkg: String? = null
    private var profile: Profile? = null
    private var editor: Editor? = null
    private val stickOn = BooleanArray(2)
    private val hatOn = BooleanArray(4)
    private var startDown = false
    private var selectDown = false
    private var comboFired = false
    private val handler = Handler(Looper.getMainLooper())
    private val toggled = BooleanArray(Control.values().size)
    private val turbo = HashMap<Int, Runnable>()

    // Режим «стрелки»: стик нажимает 4 точки вокруг центра кружка.
    private val arrOn = BooleanArray(8)
    private val adx = floatArrayOf(0f, 0f, -1f, 1f)
    private val ady = floatArrayOf(-1f, 1f, 0f, 0f)

    // Режим «камера»: палец ползёт от центра в сторону стика, у края возвращается в центр.
    private val camOn = BooleanArray(2)
    private val camAx = FloatArray(2)
    private val camAy = FloatArray(2)
    private val camOx = FloatArray(2)
    private val camOy = FloatArray(2)
    private val camCx = FloatArray(2)
    private val camCy = FloatArray(2)
    private val camR = FloatArray(2)
    private var camSpeed = 1f
    private var camRunning = false

    private val camTick = object : Runnable {
        override fun run() {
            var any = false
            for (i in 0..1) {
                if (!camOn[i]) continue
                any = true
                val c = if (i == 0) Control.LSTICK else Control.RSTICK
                camOx[i] += camAx[i] * camR[i] * 0.08f * camSpeed
                camOy[i] += camAy[i] * camR[i] * 0.08f * camSpeed
                if (hypot(camOx[i], camOy[i]) > camR[i]) {
                    engine.up(c.ordinal)
                    camOx[i] = 0f
                    camOy[i] = 0f
                    engine.down(c.ordinal, camCx[i], camCy[i])
                } else {
                    engine.move(c.ordinal, camCx[i] + camOx[i], camCy[i] + camOy[i])
                }
            }
            if (any) handler.postDelayed(this, 25) else camRunning = false
        }
    }

    /** Нажатие кнопки с учётом её режима: удержание / тап / переключатель / турбо. */
    private fun button(c: Control, pr: Profile, cfg: Cfg, w: Float, h: Float, down: Boolean) {
        val id = c.ordinal
        val t = (if (cfg.r >= 0) pr.c[Control.values()[cfg.r]] else null) ?: cfg
        val x = t.x * w
        val y = t.y * h
        when (cfg.m) {
            1 -> if (down) {
                engine.down(id, x, y)
                handler.postDelayed({ engine.up(id) }, 60)
            }
            2 -> if (down) {
                if (toggled[id]) {
                    toggled[id] = false
                    engine.up(id)
                } else {
                    toggled[id] = true
                    engine.down(id, x, y)
                }
            }
            3 -> if (down) startTurbo(id, x, y) else stopTurbo(id)
            else -> if (down) engine.down(id, x, y) else engine.up(id)
        }
    }

    private fun startTurbo(id: Int, x: Float, y: Float) {
        if (turbo.containsKey(id)) return
        val r = object : Runnable {
            var on = false
            override fun run() {
                if (on) engine.up(id) else engine.down(id, x, y)
                on = !on
                handler.postDelayed(this, 70)
            }
        }
        turbo[id] = r
        handler.post(r)
    }

    private fun stopTurbo(id: Int) {
        val r = turbo.remove(id)
        if (r != null) handler.removeCallbacks(r)
        engine.up(id)
    }

    override fun onServiceConnected() {
        Store.init(this)
        engine = TouchEngine(this)
        fab = Fab(this) { openEditor() }
        if (Build.VERSION.SDK_INT >= 34) {
            try {
                val info = serviceInfo
                info.setMotionEventSources(InputDevice.SOURCE_JOYSTICK)
                serviceInfo = info
            } catch (e: Throwable) {
            }
        }
    }

    private fun screen(): Pair<Float, Float> {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val m = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(m)
        return Pair(m.widthPixels.toFloat(), m.heightPixels.toFloat())
    }

    private fun ignored(p: String): Boolean {
        if (p == "com.android.systemui") return true
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        return imm.enabledInputMethodList.any { it.packageName == p }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val p = e.packageName?.toString() ?: return
        // Окна самого PadMap (редактор, кнопка ⚙) не считаем сменой приложения.
        if (p == packageName && e.className?.toString() != MainActivity::class.java.name) return
        if (ignored(p)) return
        if (p != pkg) {
            editor?.close()
            releaseEverything()
            pkg = p
            profile = Store.load(p)
        }
        if (Store.pending == p && editor == null) {
            Store.pending = null
            openEditor()
        }
        updateFab()
    }

    private fun updateFab() {
        if (profile != null && editor == null && Store.fabOn) fab.show() else fab.hide()
    }

    private fun openEditor() {
        val p = pkg ?: return
        if (p == packageName) return
        if (editor != null) return
        releaseEverything()
        fab.hide()
        val ed = Editor(this, p) {
            editor = null
            if (pkg == p) profile = Store.load(p)
            updateFab()
        }
        editor = ed
        ed.show()
    }

    private fun releaseEverything() {
        for (r in turbo.values) handler.removeCallbacks(r)
        turbo.clear()
        toggled.fill(false)
        arrOn.fill(false)
        camOn.fill(false)
        engine.releaseAll()
        stickOn.fill(false)
        hatOn.fill(false)
    }

    override fun onInterrupt() {
        releaseEverything()
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val src = event.source
        val isPad = (src and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
            (src and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
        if (!isPad) return false

        // Старт + Выбор вместе — открыть редактор управления.
        val isDown = event.action == KeyEvent.ACTION_DOWN
        if (event.keyCode == KeyEvent.KEYCODE_BUTTON_START) startDown = isDown
        if (event.keyCode == KeyEvent.KEYCODE_BUTTON_SELECT) selectDown = isDown
        if (editor != null) return false
        if (startDown && selectDown) {
            if (!comboFired) {
                comboFired = true
                openEditor()
            }
            return true
        }
        if (!startDown && !selectDown) comboFired = false

        val pr = profile ?: return false
        val c = Control.fromKey(event.keyCode) ?: return false
        val cfg = pr.c[c] ?: return false
        if (!cfg.on) return false
        val (w, h) = screen()
        when (event.action) {
            KeyEvent.ACTION_DOWN -> if (event.repeatCount == 0) button(c, pr, cfg, w, h, true)
            KeyEvent.ACTION_UP -> button(c, pr, cfg, w, h, false)
        }
        return true
    }

    // Android 14+: сюда приходят движения стиков.
    override fun onMotionEvent(event: MotionEvent) {
        val pr = profile ?: return
        if (editor != null) return
        if ((event.source and InputDevice.SOURCE_JOYSTICK) == 0) return
        val (w, h) = screen()

        stick(0, Control.LSTICK, pr, w, h,
            event.getAxisValue(MotionEvent.AXIS_X), event.getAxisValue(MotionEvent.AXIS_Y))

        val zx = event.getAxisValue(MotionEvent.AXIS_Z)
        val zy = event.getAxisValue(MotionEvent.AXIS_RZ)
        val rx = event.getAxisValue(MotionEvent.AXIS_RX)
        val ry = event.getAxisValue(MotionEvent.AXIS_RY)
        if (hypot(zx, zy) >= hypot(rx, ry)) stick(1, Control.RSTICK, pr, w, h, zx, zy)
        else stick(1, Control.RSTICK, pr, w, h, rx, ry)

        val hx = event.getAxisValue(MotionEvent.AXIS_HAT_X)
        val hy = event.getAxisValue(MotionEvent.AXIS_HAT_Y)
        hat(0, Control.DUP, pr, w, h, hy < -0.5f)
        hat(1, Control.DDOWN, pr, w, h, hy > 0.5f)
        hat(2, Control.DLEFT, pr, w, h, hx < -0.5f)
        hat(3, Control.DRIGHT, pr, w, h, hx > 0.5f)
    }

    private fun hat(i: Int, c: Control, pr: Profile, w: Float, h: Float, pressed: Boolean) {
        val cfg = pr.c[c] ?: return
        if (!cfg.on) return
        if (pressed && !hatOn[i]) {
            hatOn[i] = true
            button(c, pr, cfg, w, h, true)
        } else if (!pressed && hatOn[i]) {
            hatOn[i] = false
            button(c, pr, cfg, w, h, false)
        }
    }

    private fun stick(i: Int, c: Control, pr: Profile, w: Float, h: Float, ax: Float, ay: Float) {
        val cfg = pr.c[c] ?: return
        if (!cfg.on) return
        val cx = cfg.x * w
        val cy = cfg.y * h
        val r = min(w, h) * Model.STICK_R * cfg.s
        when (cfg.m) {
            1 -> arrows(i, c, cx, cy, r, ax, ay)
            2 -> camera(i, c, pr, cx, cy, r, ax, ay)
            else -> joystick(i, c, pr, cx, cy, r, ax, ay)
        }
    }

    private fun arrows(i: Int, c: Control, cx: Float, cy: Float, r: Float, ax: Float, ay: Float) {
        for (k in 0 until 4) {
            val v = when (k) {
                0 -> -ay
                1 -> ay
                2 -> -ax
                else -> ax
            }
            val idx = i * 4 + k
            val id = 100 + c.ordinal * 4 + k
            val pressed = v > (if (arrOn[idx]) 0.35f else 0.55f)
            if (pressed && !arrOn[idx]) {
                arrOn[idx] = true
                engine.down(id, cx + adx[k] * r, cy + ady[k] * r)
            } else if (!pressed && arrOn[idx]) {
                arrOn[idx] = false
                engine.up(id)
            }
        }
    }

    private fun camera(i: Int, c: Control, pr: Profile, cx: Float, cy: Float, r: Float, ax: Float, ay: Float) {
        val active = hypot(ax, ay) > pr.dead
        camAx[i] = if (active) ax else 0f
        camAy[i] = if (active) ay else 0f
        camCx[i] = cx
        camCy[i] = cy
        camR[i] = r
        camSpeed = pr.sens
        if (active && !camOn[i]) {
            camOn[i] = true
            camOx[i] = 0f
            camOy[i] = 0f
            engine.down(c.ordinal, cx, cy)
            if (!camRunning) {
                camRunning = true
                handler.post(camTick)
            }
        } else if (!active && camOn[i]) {
            camOn[i] = false
            engine.up(c.ordinal)
        }
    }

    /**
     * Джойстик: палец ставится в центр кружка и двигается от центра на величину отклонения.
     * Мёртвая зона «вычитается», чтобы движение начиналось плавно; вход и выход из зоны
     * разнесены (гистерезис), чтобы палец не дёргался у центра.
     */
    private fun joystick(i: Int, c: Control, pr: Profile, cx: Float, cy: Float, r: Float, ax: Float, ay: Float) {
        val mag = hypot(ax, ay)
        val active = mag > (if (stickOn[i]) pr.dead * 0.45f else pr.dead)
        if (active) {
            val dz = pr.dead * 0.5f
            val m = ((min(mag * pr.sens, 1f) - dz) / (1f - dz)).coerceAtLeast(0f)
            val tx = cx + ax / mag * m * r
            val ty = cy + ay / mag * m * r
            if (!stickOn[i] || !engine.isDown(c.ordinal)) {
                stickOn[i] = true
                engine.down(c.ordinal, cx, cy)
            }
            engine.move(c.ordinal, tx, ty)
        } else if (stickOn[i]) {
            stickOn[i] = false
            engine.up(c.ordinal)
        }
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        releaseEverything()
        editor?.close()
        fab.hide()
        return super.onUnbind(intent)
    }
}
