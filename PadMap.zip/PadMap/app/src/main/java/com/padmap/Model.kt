package com.padmap

import android.content.Context
import android.content.SharedPreferences
import android.view.KeyEvent
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.min

object Model {
    /** Радиус стика на экране как доля от меньшей стороны экрана (при размере 1.0). */
    const val STICK_R = 0.13f

    /** Радиус кружка в пикселях. Для стика это ещё и «ход» пальца. */
    fun radius(c: Control, scale: Float, w: Float, h: Float, d: Float): Float =
        if (c.stick) min(w, h) * STICK_R * scale else 30f * d * scale
}

enum class Control(
    val label: String,
    val title: String,
    val keyCode: Int,
    val dx: Float,
    val dy: Float,
    val on: Boolean,
    val stick: Boolean = false
) {
    LSTICK("Лев. стик", "Левый стик (движение)", -1, 0.15f, 0.68f, true, true),
    RSTICK("Прав. стик", "Правый стик (камера)", -1, 0.60f, 0.62f, false, true),
    A("A", "Кнопка A", KeyEvent.KEYCODE_BUTTON_A, 0.88f, 0.80f, true),
    B("B", "Кнопка B", KeyEvent.KEYCODE_BUTTON_B, 0.94f, 0.64f, true),
    X("X", "Кнопка X", KeyEvent.KEYCODE_BUTTON_X, 0.82f, 0.64f, true),
    Y("Y", "Кнопка Y", KeyEvent.KEYCODE_BUTTON_Y, 0.88f, 0.48f, true),
    L1("L1", "Левый бампер (L1)", KeyEvent.KEYCODE_BUTTON_L1, 0.06f, 0.30f, true),
    R1("R1", "Правый бампер (R1)", KeyEvent.KEYCODE_BUTTON_R1, 0.94f, 0.30f, true),
    L2("L2", "Левый курок (L2)", KeyEvent.KEYCODE_BUTTON_L2, 0.06f, 0.14f, true),
    R2("R2", "Правый курок (R2)", KeyEvent.KEYCODE_BUTTON_R2, 0.94f, 0.14f, true),
    START("Старт", "Кнопка «Старт»", KeyEvent.KEYCODE_BUTTON_START, 0.56f, 0.08f, false),
    SELECT("Выбор", "Кнопка «Выбор» (Select)", KeyEvent.KEYCODE_BUTTON_SELECT, 0.44f, 0.08f, false),
    THUMBL("Лев. клик", "Нажатие на левый стик (L3)", KeyEvent.KEYCODE_BUTTON_THUMBL, 0.28f, 0.88f, false),
    THUMBR("Прав. клик", "Нажатие на правый стик (R3)", KeyEvent.KEYCODE_BUTTON_THUMBR, 0.66f, 0.88f, false),
    DUP("↑", "Крестовина: вверх", KeyEvent.KEYCODE_DPAD_UP, 0.30f, 0.46f, false),
    DDOWN("↓", "Крестовина: вниз", KeyEvent.KEYCODE_DPAD_DOWN, 0.30f, 0.70f, false),
    DLEFT("←", "Крестовина: влево", KeyEvent.KEYCODE_DPAD_LEFT, 0.24f, 0.58f, false),
    DRIGHT("→", "Крестовина: вправо", KeyEvent.KEYCODE_DPAD_RIGHT, 0.36f, 0.58f, false);

    companion object {
        fun fromKey(k: Int): Control? = values().firstOrNull { it.keyCode == k }
    }
}

/** Настройка одной кнопки: позиция (доля экрана), включена ли, размер (1.0 = обычный). */
/**
 * m — режим. Кнопка: 0 удержание, 1 тап, 2 переключатель, 3 турбо.
 * Стик: 0 джойстик, 1 стрелки, 2 камера.
 * r — переназначение: -1 своя точка, иначе номер кнопки, в чью точку нажимать.
 */
class Cfg(var x: Float, var y: Float, var on: Boolean, var s: Float = 1f, var m: Int = 0, var r: Int = -1)

/** dead — мёртвая зона стиков, sens — чувствительность стиков. */
class Profile(val c: MutableMap<Control, Cfg>, var dead: Float = 0.1f, var sens: Float = 1f, var alpha: Float = 1f) {
    companion object {
        fun default(): Profile {
            val m = LinkedHashMap<Control, Cfg>()
            for (k in Control.values()) m[k] = Cfg(k.dx, k.dy, k.on)
            return Profile(m)
        }
    }
}

object Store {
    private var sp: SharedPreferences? = null

    fun init(ctx: Context) {
        if (sp == null) sp = ctx.applicationContext.getSharedPreferences("padmap", Context.MODE_PRIVATE)
    }

    private fun prefs(): SharedPreferences = sp!!

    private var crashInstalled = false

    /** Последняя ошибка приложения (показывается на главном экране). */
    var lastError: String?
        get() = prefs().getString("last_error", null)
        set(v) {
            prefs().edit().putString("last_error", v).apply()
        }

    fun logError(t: Throwable, sync: Boolean = false) {
        try {
            val txt = android.util.Log.getStackTraceString(t).take(3500)
            val e = prefs().edit().putString("last_error", txt)
            if (sync) e.commit() else e.apply()
        } catch (x: Throwable) {
        }
    }

    /** Записывает необработанные падения, чтобы их можно было показать и скопировать. */
    fun installCrashLog() {
        if (crashInstalled) return
        crashInstalled = true
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { th, ex ->
            logError(ex, true)
            prev?.uncaughtException(th, ex)
        }
    }

    var pending: String?
        get() = prefs().getString("pending", null)
        set(v) {
            prefs().edit().putString("pending", v).apply()
        }

    /** Показывать ли плавающую кнопку ⚙ поверх игр. */
    var fabOn: Boolean
        get() = prefs().getBoolean("fab_on", true)
        set(v) {
            prefs().edit().putBoolean("fab_on", v).apply()
        }

    /** true — кнопка ⚙ во всех приложениях, false — только в настроенных играх. */
    var fabAll: Boolean
        get() = prefs().getBoolean("fab_all", true)
        set(v) {
            prefs().edit().putBoolean("fab_all", v).apply()
        }

    var fabX: Int
        get() = prefs().getInt("fab_x", -1)
        set(v) {
            prefs().edit().putInt("fab_x", v).apply()
        }

    var fabY: Int
        get() = prefs().getInt("fab_y", -1)
        set(v) {
            prefs().edit().putInt("fab_y", v).apply()
        }

    fun load(pkg: String): Profile? {
        val s = prefs().getString("p_$pkg", null) ?: return null
        return try {
            val j = JSONObject(s)
            val p = Profile.default()
            p.dead = j.optDouble("_dead", 0.1).toFloat()
            p.sens = j.optDouble("_sens", 1.0).toFloat()
            p.alpha = j.optDouble("_alpha", 1.0).toFloat()
            for (k in Control.values()) {
                val a = j.optJSONArray(k.name) ?: continue
                val sc = if (a.length() > 3) a.getDouble(3).toFloat() else 1f
                p.c[k] = Cfg(a.getDouble(0).toFloat(), a.getDouble(1).toFloat(), a.getInt(2) == 1, sc, if (a.length() > 4) a.getInt(4) else 0, if (a.length() > 5) a.getInt(5) else -1)
            }
            p
        } catch (e: Exception) {
            null
        }
    }

    fun save(pkg: String, p: Profile) {
        val j = JSONObject()
        for ((k, g) in p.c) {
            j.put(
                k.name,
                JSONArray().put(g.x.toDouble()).put(g.y.toDouble()).put(if (g.on) 1 else 0).put(g.s.toDouble()).put(g.m).put(g.r)
            )
        }
        j.put("_dead", p.dead.toDouble())
        j.put("_sens", p.sens.toDouble())
        j.put("_alpha", p.alpha.toDouble())
        prefs().edit().putString("p_$pkg", j.toString()).apply()
    }

    fun delete(pkg: String) {
        prefs().edit().remove("p_$pkg").apply()
    }

    fun saved(): List<String> =
        prefs().all.keys.filter { it.startsWith("p_") }.map { it.substring(2) }
}
