package com.padmap

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.PixelFormat
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import kotlin.math.hypot

/** Маленькая перетаскиваемая кнопка ⚙ поверх игры: открывает редактор управления. */
class Fab(private val svc: AccessibilityService, private val onTap: () -> Unit) {

    private val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val d = svc.resources.displayMetrics.density
    private var view: TextView? = null

    fun show() {
        if (view != null) return
        val size = (46 * d).toInt()

        val m = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(m)

        val v = TextView(svc)
        v.text = "⚙"
        v.textSize = 22f
        v.setTextColor(0xFFFFFFFF.toInt())
        v.gravity = Gravity.CENTER
        v.alpha = 0.6f
        val bg = Ui.oval(0xCC1A2233.toInt())
        bg.setStroke((2 * d).toInt(), Ui.ACCENT)
        v.background = bg

        val lp = WindowManager.LayoutParams(
            size,
            size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        val sx = Store.fabX
        val sy = Store.fabY
        lp.x = (if (sx >= 0) sx else (8 * d).toInt()).coerceIn(0, (m.widthPixels - size).coerceAtLeast(0))
        lp.y = (if (sy >= 0) sy else (m.heightPixels * 0.4f).toInt()).coerceIn(0, (m.heightPixels - size).coerceAtLeast(0))

        v.setOnTouchListener(object : View.OnTouchListener {
            var sxr = 0f
            var syr = 0f
            var ox = 0
            var oy = 0
            var moved = false

            override fun onTouch(view: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        sxr = e.rawX
                        syr = e.rawY
                        ox = lp.x
                        oy = lp.y
                        moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - sxr
                        val dy = e.rawY - syr
                        if (hypot(dx, dy) > 10 * d) moved = true
                        if (moved) {
                            lp.x = (ox + dx.toInt()).coerceIn(0, (m.widthPixels - size).coerceAtLeast(0))
                            lp.y = (oy + dy.toInt()).coerceIn(0, (m.heightPixels - size).coerceAtLeast(0))
                            try {
                                wm.updateViewLayout(view, lp)
                            } catch (ex: Exception) {
                            }
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        if (moved) {
                            Store.fabX = lp.x
                            Store.fabY = lp.y
                        } else {
                            onTap()
                        }
                    }
                }
                return true
            }
        })

        try {
            wm.addView(v, lp)
            view = v
        } catch (e: Exception) {
        }
    }

    fun hide() {
        val v = view ?: return
        try {
            wm.removeView(v)
        } catch (e: Exception) {
        }
        view = null
    }
}
