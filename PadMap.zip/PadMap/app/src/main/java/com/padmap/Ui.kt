package com.padmap

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.TextView

/** Общие цвета и мелкие помощники для оформления. */
object Ui {
    val BG = 0xFF0F1420.toInt()
    val CARD = 0xFF1A2233.toInt()
    val CARD2 = 0xFF26324D.toInt()
    val ACCENT = 0xFF4FC3F7.toInt()
    val ON_ACCENT = 0xFF06121C.toInt()
    val TEXT = 0xFFEAF0FA.toInt()
    val MUTED = 0xFF8A97AD.toInt()
    val GOOD = 0xFF4CD08B.toInt()
    val BAD = 0xFFFF6B6B.toInt()

    fun rounded(color: Int, radius: Float): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.RECTANGLE
        g.cornerRadius = radius
        g.setColor(color)
        return g
    }

    fun oval(color: Int): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(color)
        return g
    }

    /** Кнопка-«таблетка» (обычный TextView, чтобы не зависеть от темы). */
    fun btn(
        ctx: Context,
        text: String,
        bg: Int,
        fg: Int,
        d: Float,
        padH: Int = 16,
        onClick: () -> Unit
    ): TextView {
        val v = TextView(ctx)
        v.text = text
        v.setTextColor(fg)
        v.textSize = 14f
        v.typeface = Typeface.DEFAULT_BOLD
        v.gravity = Gravity.CENTER
        v.setPadding((padH * d).toInt(), (11 * d).toInt(), (padH * d).toInt(), (11 * d).toInt())
        v.background = rounded(bg, 12 * d)
        v.setOnClickListener { onClick() }
        return v
    }
}
