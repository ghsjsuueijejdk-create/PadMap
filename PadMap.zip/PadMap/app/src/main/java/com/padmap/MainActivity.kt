package com.padmap

import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.ComponentName
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

private class AppItem(val pkg: String, val name: String, loader: () -> Drawable) {
    val icon: Drawable by lazy(loader)
}

class MainActivity : Activity() {

    private var d = 1f
    private lateinit var statusDot: View
    private lateinit var statusText: TextView
    private lateinit var serviceBtn: TextView
    private lateinit var gamesBox: LinearLayout

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private fun px(v: Int): Int = (v * d).toInt()

    private fun tv(text: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        t.setPadding(0, px(3), 0, px(3))
        return t
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = Ui.rounded(Ui.CARD, 18 * d)
        c.setPadding(px(16), px(14), px(16), px(16))
        return c
    }

    private fun add(parent: LinearLayout, v: View, top: Int = 12) {
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.topMargin = px(top)
        parent.addView(v, lp)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Store.init(this)
        d = resources.displayMetrics.density
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(px(20), px(24), px(20), px(40))

        col.addView(tv("PadMap", 34f, Ui.ACCENT, true))
        col.addView(tv("Играй геймпадом в любые игры: кнопки и стики превращаются в касания экрана.", 14f, Ui.MUTED))

        // --- Служба ---
        val sc = card()
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        statusDot = View(this)
        val dotLp = LinearLayout.LayoutParams(px(12), px(12))
        dotLp.rightMargin = px(10)
        row.addView(statusDot, dotLp)
        statusText = tv("", 17f, Ui.TEXT, true)
        row.addView(statusText)
        sc.addView(row)
        sc.addView(tv("Включается один раз в «Специальных возможностях».", 13f, Ui.MUTED))
        serviceBtn = Ui.btn(this, "Открыть настройки службы", Ui.ACCENT, Ui.ON_ACCENT, d) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        add(sc, serviceBtn, 10)
        add(sc, tv("Если пункт серый: Настройки → Приложения → PadMap → ⋮ → «Разрешить ограниченные настройки».", 12f, Ui.MUTED), 8)
        add(col, sc, 18)

        // --- Игры ---
        add(col, tv("МОИ ИГРЫ", 12f, Ui.MUTED, true), 22)
        val addBtn = Ui.btn(this, "＋  Добавить игру", Ui.CARD2, Ui.ACCENT, d) { pickGame() }
        add(col, addBtn, 6)
        gamesBox = LinearLayout(this)
        gamesBox.orientation = LinearLayout.VERTICAL
        add(col, gamesBox, 6)

        // --- Подсказка про настройку в игре ---
        val tips = card()
        tips.addView(tv("Настройка прямо в игре", 16f, Ui.TEXT, true))
        tips.addView(
            tv(
                "Нажми кнопку ⚙ поверх игры или зажми на геймпаде «Старт» + «Выбор» — откроется редактор: можно двигать кнопки и менять их размер.",
                13f, Ui.MUTED
            )
        )
        val sw = Switch(this)
        sw.text = "Показывать кнопку ⚙ в играх"
        sw.setTextColor(Ui.TEXT)
        sw.textSize = 14f
        sw.isChecked = Store.fabOn
        sw.setOnCheckedChangeListener { _, on -> Store.fabOn = on }
        add(tips, sw, 8)
        add(col, tips, 22)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Ui.BG)
        scroll.addView(col)
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        val on = serviceOn()
        statusText.text = if (on) "Служба включена" else "Служба выключена"
        statusDot.background = Ui.oval(if (on) Ui.GOOD else Ui.BAD)
        serviceBtn.text = if (on) "Настройки службы" else "Включить службу"
        refreshGames()
    }

    private fun serviceOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        val me = ComponentName(this, PadService::class.java).flattenToString()
        return s.split(":").any { it.equals(me, true) }
    }

    private fun label(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg
    }

    private fun refreshGames() {
        gamesBox.removeAllViews()
        val list = Store.saved().sortedBy { label(it).lowercase() }
        if (list.isEmpty()) {
            gamesBox.addView(
                tv("Пока нет настроенных игр. Нажми «Добавить игру», выбери игру и расставь кнопки.", 13f, Ui.MUTED)
            )
            return
        }
        for (p in list) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.background = Ui.rounded(Ui.CARD, 16 * d)
            row.setPadding(px(12), px(10), px(10), px(10))

            val icon = ImageView(this)
            try {
                icon.setImageDrawable(packageManager.getApplicationIcon(p))
            } catch (e: Exception) {
            }
            row.addView(icon, LinearLayout.LayoutParams(px(44), px(44)))

            val name = tv(label(p), 16f, Ui.TEXT, true)
            val nlp = LinearLayout.LayoutParams(0, WRAP, 1f)
            nlp.leftMargin = px(12)
            row.addView(name, nlp)

            val edit = Ui.btn(this, "Настроить", Ui.CARD2, Ui.ACCENT, d, 12) { launchEdit(p) }
            row.addView(edit)
            val del = Ui.btn(this, "✕", Ui.CARD2, Ui.BAD, d, 12) { confirmDelete(p) }
            val dlp = LinearLayout.LayoutParams(WRAP, WRAP)
            dlp.leftMargin = px(6)
            row.addView(del, dlp)

            add(gamesBox, row, 8)
        }
    }

    private fun confirmDelete(p: String) {
        AlertDialog.Builder(this)
            .setTitle("Удалить настройки?")
            .setMessage(label(p))
            .setPositiveButton("Удалить") { _, _ ->
                Store.delete(p)
                refreshGames()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun launchEdit(pkg: String) {
        if (!serviceOn()) {
            AlertDialog.Builder(this)
                .setMessage("Сначала включи службу PadMap в «Специальных возможностях».")
                .setPositiveButton("Открыть") { _, _ ->
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
                .setNegativeButton("Отмена", null)
                .show()
            return
        }
        val i = packageManager.getLaunchIntentForPackage(pkg) ?: return
        Store.pending = pkg
        startActivity(i)
    }

    /** Для новой игры предлагает взять раскладку из уже настроенной. */
    private fun startSetup(pkg: String) {
        val others = Store.saved().filter { it != pkg }
        if (Store.load(pkg) != null || others.isEmpty()) {
            launchEdit(pkg)
            return
        }
        val names = arrayOf("Начать с нуля") + others.map { label(it) }
        AlertDialog.Builder(this)
            .setTitle("Взять раскладку из другой игры?")
            .setItems(names) { _, which ->
                if (which > 0) {
                    val src = Store.load(others[which - 1])
                    if (src != null) Store.save(pkg, src)
                }
                launchEdit(pkg)
            }
            .show()
    }

    private fun pickGame() {
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val all = pm.queryIntentActivities(q, 0)
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .map { ri -> AppItem(ri.activityInfo.packageName, ri.loadLabel(pm).toString()) { ri.loadIcon(pm) } }
            .sortedBy { it.name.lowercase() }

        val dlg = Dialog(this, android.R.style.Theme_DeviceDefault_NoActionBar)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.BG)
        root.setPadding(px(16), px(20), px(16), 0)

        root.addView(tv("Выбери игру", 22f, Ui.TEXT, true))

        val search = EditText(this)
        search.hint = "Поиск"
        search.setHintTextColor(Ui.MUTED)
        search.setTextColor(Ui.TEXT)
        search.setSingleLine(true)
        search.background = Ui.rounded(Ui.CARD, 14 * d)
        search.setPadding(px(14), px(12), px(14), px(12))
        val slp = LinearLayout.LayoutParams(MATCH, WRAP)
        slp.topMargin = px(10)
        slp.bottomMargin = px(10)
        root.addView(search, slp)

        var shown: List<AppItem> = all
        val adapter = object : BaseAdapter() {
            override fun getCount(): Int = shown.size
            override fun getItem(position: Int): Any = shown[position]
            override fun getItemId(position: Int): Long = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val item = shown[position]
                val row = LinearLayout(this@MainActivity)
                row.orientation = LinearLayout.HORIZONTAL
                row.gravity = Gravity.CENTER_VERTICAL
                row.setPadding(px(6), px(8), px(6), px(8))
                val icon = ImageView(this@MainActivity)
                icon.setImageDrawable(item.icon)
                row.addView(icon, LinearLayout.LayoutParams(px(40), px(40)))
                val name = tv(item.name, 16f, Ui.TEXT)
                val nlp = LinearLayout.LayoutParams(0, WRAP, 1f)
                nlp.leftMargin = px(14)
                row.addView(name, nlp)
                return row
            }
        }

        val lv = ListView(this)
        lv.divider = null
        lv.setSelector(ColorDrawable(0x22FFFFFF))
        lv.adapter = adapter
        lv.setOnItemClickListener { _, _, pos, _ ->
            val pkg = shown[pos].pkg
            dlg.dismiss()
            startSetup(pkg)
        }
        root.addView(lv, LinearLayout.LayoutParams(MATCH, 0, 1f))

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val t = s?.toString()?.trim()?.lowercase() ?: ""
                shown = if (t.isEmpty()) all else all.filter { it.name.lowercase().contains(t) }
                adapter.notifyDataSetChanged()
            }
        })

        dlg.setContentView(root)
        dlg.window?.setBackgroundDrawable(ColorDrawable(Ui.BG))
        dlg.window?.statusBarColor = Ui.BG
        dlg.window?.navigationBarColor = Ui.BG
        dlg.show()
    }
}
