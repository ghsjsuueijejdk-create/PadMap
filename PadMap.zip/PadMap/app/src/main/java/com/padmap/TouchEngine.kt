package com.padmap

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper

/**
 * Держит набор "пальцев" и непрерывно отправляет их в экран короткими
 * кусками жеста (continueStroke), чтобы палец оставался зажатым и двигался.
 */
class TouchEngine(private val svc: AccessibilityService) {

    private class Ptr(var x: Float, var y: Float) {
        var lastX = x
        var lastY = y
        var stroke: GestureDescription.StrokeDescription? = null
        var releasing = false
        var finalSent = false
    }

    private val ptrs = LinkedHashMap<Int, Ptr>()
    private var inFlight = false
    private val handler = Handler(Looper.getMainLooper())
    private val seg = 40L

    fun isDown(id: Int): Boolean {
        val p = ptrs[id]
        return p != null && !p.releasing
    }

    fun down(id: Int, x: Float, y: Float) {
        if (ptrs.containsKey(id)) return
        ptrs[id] = Ptr(x, y)
        pump()
    }

    fun move(id: Int, x: Float, y: Float) {
        val p = ptrs[id] ?: return
        if (p.releasing) return
        p.x = x
        p.y = y
    }

    fun up(id: Int) {
        val p = ptrs[id] ?: return
        p.releasing = true
        pump()
    }

    fun releaseAll() {
        for (p in ptrs.values) p.releasing = true
        pump()
    }

    private val callback = object : AccessibilityService.GestureResultCallback() {
        override fun onCompleted(g: GestureDescription?) {
            inFlight = false
            ptrs.values.removeAll { it.finalSent }
            pump()
        }

        override fun onCancelled(g: GestureDescription?) {
            inFlight = false
            ptrs.values.removeAll { it.finalSent || it.releasing }
            for (p in ptrs.values) p.stroke = null
            pump()
        }
    }

    private fun pump() {
        if (inFlight || ptrs.isEmpty()) return
        val b = GestureDescription.Builder()
        val max = GestureDescription.getMaxStrokeCount()
        var n = 0
        for (p in ptrs.values) {
            if (n >= max) break
            val path = Path()
            path.moveTo(p.lastX, p.lastY)
            if (p.x != p.lastX || p.y != p.lastY) path.lineTo(p.x, p.y)
            val cont = !p.releasing
            val s = p.stroke?.continueStroke(path, 0, seg, cont)
                ?: GestureDescription.StrokeDescription(path, 0, seg, cont)
            p.stroke = s
            p.finalSent = p.releasing
            p.lastX = p.x
            p.lastY = p.y
            b.addStroke(s)
            n++
        }
        inFlight = true
        val ok = svc.dispatchGesture(b.build(), callback, handler)
        if (!ok) {
            inFlight = false
            ptrs.clear()
        }
    }
}
