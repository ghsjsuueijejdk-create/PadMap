package com.padmap

import android.content.Context
import android.content.SharedPreferences
import android.view.KeyEvent
import org.json.JSONArray
import org.json.JSONObject

object Model {
    /** Радиус стика на экране как доля от меньшей стороны экрана. */
    const val STICK_R = 0.13f
}

enum class Control(
    val label: String,
    val keyCode: Int,
    val dx: Float,
    val dy: Float,
    val on: Boolean,
    val stick: Boolean = false
) {
    LSTICK("ЛС", -1, 0.15f, 0.68f, true, true),
    RSTICK("ПС", -1, 0.60f, 0.62f, false, true),
    A("A", KeyEvent.KEYCODE_BUTTON_A, 0.88f, 0.80f, true),
    B("B", KeyEvent.KEYCODE_BUTTON_B, 0.94f, 0.64f, true),
    X("X", KeyEvent.KEYCODE_BUTTON_X, 0.82f, 0.64f, true),
    Y("Y", KeyEvent.KEYCODE_BUTTON_Y, 0.88f, 0.48f, true),
    L1("L1", KeyEvent.KEYCODE_BUTTON_L1, 0.06f, 0.30f, true),
    R1("R1", KeyEvent.KEYCODE_BUTTON_R1, 0.94f, 0.30f, true),
    L2("L2", KeyEvent.KEYCODE_BUTTON_L2, 0.06f, 0.14f, true),
    R2("R2", KeyEvent.KEYCODE_BUTTON_R2, 0.94f, 0.14f, true),
    START("St", KeyEvent.KEYCODE_BUTTON_START, 0.56f, 0.08f, false),
    SELECT("Se", KeyEvent.KEYCODE_BUTTON_SELECT, 0.44f, 0.08f, false),
    THUMBL("ЛН", KeyEvent.KEYCODE_BUTTON_THUMBL, 0.28f, 0.88f, false),
    THUMBR("ПН", KeyEvent.KEYCODE_BUTTON_THUMBR, 0.66f, 0.88f, false),
    DUP("↑", KeyEvent.KEYCODE_DPAD_UP, 0.30f, 0.46f, false),
    DDOWN("↓", KeyEvent.KEYCODE_DPAD_DOWN, 0.30f, 0.70f, false),
    DLEFT("←", KeyEvent.KEYCODE_DPAD_LEFT, 0.24f, 0.58f, false),
    DRIGHT("→", KeyEvent.KEYCODE_DPAD_RIGHT, 0.36f, 0.58f, false);

    companion object {
        fun fromKey(k: Int): Control? = values().firstOrNull { it.keyCode == k }
    }
}

class Cfg(var x: Float, var y: Float, var on: Boolean)

class Profile(val c: MutableMap<Control, Cfg>) {
    companion object {
        fun default(): Profile {
            val m = LinkedHashMap<Control, Cfg>()
            for (k in Control.values()) m[k] = Cfg(k.dx, k.dy, k.on)
            return Profile(m)
        }
    }
}

object Store {
    private var sp: SharedPreferences? = null

    fun init(ctx: Context) {
        if (sp == null) sp = ctx.applicationContext.getSharedPreferences("padmap", Context.MODE_PRIVATE)
    }

    private fun prefs(): SharedPreferences = sp!!

    var pending: String?
        get() = prefs().getString("pending", null)
        set(v) {
            prefs().edit().putString("pending", v).apply()
        }

    fun load(pkg: String): Profile? {
        val s = prefs().getString("p_$pkg", null) ?: return null
        return try {
            val j = JSONObject(s)
            val p = Profile.default()
            for (k in Control.values()) {
                val a = j.optJSONArray(k.name) ?: continue
                p.c[k] = Cfg(a.getDouble(0).toFloat(), a.getDouble(1).toFloat(), a.getInt(2) == 1)
            }
            p
        } catch (e: Exception) {
            null
        }
    }

    fun save(pkg: String, p: Profile) {
        val j = JSONObject()
        for ((k, g) in p.c) {
            j.put(k.name, JSONArray().put(g.x.toDouble()).put(g.y.toDouble()).put(if (g.on) 1 else 0))
        }
        prefs().edit().putString("p_$pkg", j.toString()).apply()
    }

    fun delete(pkg: String) {
        prefs().edit().remove("p_$pkg").apply()
    }

    fun saved(): List<String> =
        prefs().all.keys.filter { it.startsWith("p_") }.map { it.substring(2) }
}
