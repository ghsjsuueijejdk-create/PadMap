package com.padmap

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.hypot
import kotlin.math.min

class Board(ctx: Context, private val prof: Profile) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2 * d
        color = 0xFFFFFFFF.toInt()
    }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        textSize = 16 * d
    }

    private fun rad(c: Control): Float =
        if (c.stick) min(width, height) * Model.STICK_R else 26 * d

    override fun onDraw(cv: Canvas) {
        cv.drawColor(0x99000000.toInt())
        for ((c, g) in prof.c) {
            val x = g.x * width
            val y = g.y * height
            val r = rad(c)
            fill.color = if (g.on) 0x884FC3F7.toInt() else 0x33FFFFFF
            cv.drawCircle(x, y, r, fill)
            line.alpha = if (g.on) 255 else 90
            cv.drawCircle(x, y, r, line)
            txt.color = if (g.on) 0xFFFFFFFF.toInt() else 0x88FFFFFF.toInt()
            cv.drawText(c.label, x, y + txt.textSize / 3, txt)
        }
    }

    private var drag: Control? = null
    private var sx = 0f
    private var sy = 0f
    private var moved = false

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                moved = false
                sx = e.x
                sy = e.y
                drag = prof.c.keys.sortedBy { rad(it) }.firstOrNull {
                    val g = prof.c[it]!!
                    hypot(e.x - g.x * width, e.y - g.y * height) <= rad(it)
                }
            }
            MotionEvent.ACTION_MOVE -> {
                val c = drag
                if (c != null) {
                    if (hypot(e.x - sx, e.y - sy) > 12 * d) moved = true
                    if (moved) {
                        val g = prof.c[c]!!
                        g.x = (e.x / width).coerceIn(0.02f, 0.98f)
                        g.y = (e.y / height).coerceIn(0.02f, 0.98f)
                        invalidate()
                    }
                }
            }
            MotionEvent.ACTION_UP -> {
                val c = drag
                if (c != null && !moved) {
                    val g = prof.c[c]!!
                    g.on = !g.on
                    invalidate()
                }
                drag = null
            }
        }
        return true
    }
}

class Editor(
    private val svc: AccessibilityService,
    private val pkg: String,
    private val done: () -> Unit
) {
    private val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val prof = Store.load(pkg) ?: Profile.default()
    private val root = FrameLayout(svc)

    fun show() {
        val board = Board(svc, prof)
        root.addView(
            board,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        fun btn(t: String, f: () -> Unit): Button {
            val b = Button(svc)
            b.text = t
            b.setOnClickListener { f() }
            return b
        }

        val bar = LinearLayout(svc)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.addView(btn("Сохранить") {
            Store.save(pkg, prof)
            close()
        })
        bar.addView(btn("Сбросить") {
            for ((k, g) in prof.c) {
                g.x = k.dx
                g.y = k.dy
                g.on = k.on
            }
            board.invalidate()
        })
        bar.addView(btn("Отмена") { close() })
        root.addView(
            bar,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.CENTER_HORIZONTAL
            )
        )

        val hint = TextView(svc)
        hint.text = "Тяни кружки туда, куда в игре нажимаешь пальцем. Касание — включить или выключить кнопку."
        hint.setTextColor(0xFFFFFFFF.toInt())
        hint.gravity = Gravity.CENTER
        root.addView(
            hint,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM
            )
        )

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(root, lp)
    }

    fun close() {
        try {
            wm.removeView(root)
        } catch (e: Exception) {
        }
        done()
    }
}
