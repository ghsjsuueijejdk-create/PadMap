package com.padmap

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/** Полотно с кружками: выбрать — коснуться, переместить — потянуть. */
class Board(ctx: Context, private val prof: Profile) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2 * d
        color = 0xFFFFFFFF.toInt()
    }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 4 * d
        color = 0xFFFFD54F.toInt()
    }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }

    var hidden = false
    var selected: Control? = null
    var onSelect: (() -> Unit)? = null

    private var drag: Control? = null
    private var sx = 0f
    private var sy = 0f
    private var offX = 0f
    private var offY = 0f
    private var moved = false

    private fun rad(c: Control): Float {
        val s = prof.c[c]?.s ?: 1f
        return Model.radius(c, s, width.toFloat(), height.toFloat(), d)
    }

    override fun onDraw(cv: Canvas) {
        if (hidden) return
        val a = prof.alpha
        cv.drawColor((((0x88 * a).toInt()) shl 24))
        for ((c, g) in prof.c) {
            val x = g.x * width
            val y = g.y * height
            val r = rad(c)
            val fa = ((if (g.on) 0x88 else 0x33) * a).toInt()
            fill.color = if (g.on) (fa shl 24) or 0x4FC3F7 else (fa shl 24) or 0xFFFFFF
            cv.drawCircle(x, y, r, fill)
            line.alpha = ((if (g.on) 255 else 90) * a).toInt()
            cv.drawCircle(x, y, r, line)
            if (c == selected) cv.drawCircle(x, y, r + 4 * d, ring)
            drawLabel(cv, c.label, x, y, r, g.on, a)
        }
    }

    private fun drawLabel(cv: Canvas, label: String, x: Float, y: Float, r: Float, on: Boolean, a: Float) {
        val lines = label.split(" ")
        var maxLen = 2
        for (l in lines) if (l.length > maxLen) maxLen = l.length
        val size = max(9 * d, min(r * 2.6f / maxLen, 20 * d))
        txt.textSize = size
        txt.color = (((if (on) 255 else 153) * a).toInt() shl 24) or 0xFFFFFF
        val lh = size * 1.15f
        var yy = y - (lines.size - 1) * lh / 2 + size * 0.35f
        for (l in lines) {
            cv.drawText(l, x, yy, txt)
            yy += lh
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (hidden) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                moved = false
                sx = e.x
                sy = e.y
                val hit = prof.c.keys.sortedBy { rad(it) }.firstOrNull {
                    val g = prof.c[it]!!
                    hypot(e.x - g.x * width, e.y - g.y * height) <= rad(it)
                }
                drag = hit
                if (hit != null) {
                    val g = prof.c[hit]!!
                    offX = g.x * width - e.x
                    offY = g.y * height - e.y
                    selected = hit
                    onSelect?.invoke()
                    invalidate()
                }
            }
            MotionEvent.ACTION_MOVE -> {
                val c = drag
                if (c != null) {
                    if (hypot(e.x - sx, e.y - sy) > 8 * d) moved = true
                    if (moved) {
                        val g = prof.c[c]!!
                        g.x = ((e.x + offX) / width).coerceIn(0.02f, 0.98f)
                        g.y = ((e.y + offY) / height).coerceIn(0.02f, 0.98f)
                        invalidate()
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> drag = null
        }
        return true
    }
}

/** Редактор управления поверх игры. */
class Editor(
    private val svc: AccessibilityService,
    private val pkg: String,
    private val done: () -> Unit
) {
    private val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val d = svc.resources.displayMetrics.density
    private val prof = Store.load(pkg) ?: Profile.default()
    private val root = FrameLayout(svc)
    private var added = false
    private var panelTop = false

    private lateinit var board: Board
    private lateinit var panel: LinearLayout
    private lateinit var nameView: TextView
    private lateinit var toggleBtn: TextView
    private lateinit var seek: SeekBar
    private lateinit var modeBtn: TextView
    private lateinit var deadSeek: SeekBar
    private lateinit var sensSeek: SeekBar
    private lateinit var extra: LinearLayout
    private lateinit var mapBtn: TextView
    private lateinit var alphaSeek: SeekBar
    private lateinit var hideBtn: TextView
    private val modes = arrayOf("Удержание", "Тап", "Переключатель", "Турбо")
    private val stickModes = arrayOf("Джойстик", "Стрелки", "Камера")

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private fun px(v: Int): Int = (v * d).toInt()

    private fun rowParams(left: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(WRAP, WRAP)
        p.leftMargin = px(left)
        return p
    }

    private fun weightParams(left: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(0, WRAP, 1f)
        p.leftMargin = px(left)
        return p
    }

    fun show() {
        board = Board(svc, prof)
        board.onSelect = { refresh() }
        root.addView(board, FrameLayout.LayoutParams(MATCH, MATCH))

        val p = LinearLayout(svc)
        p.orientation = LinearLayout.VERTICAL
        p.background = Ui.rounded(0xEE141B2B.toInt(), 18 * d)
        p.setPadding(px(12), px(10), px(12), px(12))
        panel = p

        // Иконка и название игры
        val head = LinearLayout(svc)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val gi = ImageView(svc)
        val pm = svc.packageManager
        try {
            gi.setImageDrawable(pm.getApplicationIcon(pkg))
        } catch (e: Exception) {
        }
        head.addView(gi, LinearLayout.LayoutParams(px(28), px(28)))
        val gn = TextView(svc)
        gn.text = try {
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }
        gn.textSize = 14f
        gn.typeface = Typeface.DEFAULT_BOLD
        gn.setTextColor(Ui.TEXT)
        head.addView(gn, rowParams(8))
        p.addView(head, LinearLayout.LayoutParams(MATCH, WRAP))

        val hint = TextView(svc)
        hint.text = "Выбери кружок и тяни, чтобы переместить. Размер — ползунком."
        hint.textSize = 12f
        hint.setTextColor(Ui.MUTED)
        p.addView(hint, LinearLayout.LayoutParams(MATCH, WRAP))

        // Строка 1: название выбранной кнопки + включить/выключить
        val row1 = LinearLayout(svc)
        row1.orientation = LinearLayout.HORIZONTAL
        row1.gravity = Gravity.CENTER_VERTICAL
        nameView = TextView(svc)
        nameView.textSize = 15f
        nameView.typeface = Typeface.DEFAULT_BOLD
        nameView.setTextColor(Ui.TEXT)
        row1.addView(nameView, weightParams())
        toggleBtn = Ui.btn(svc, "Включить", Ui.CARD2, Ui.TEXT, d, 12) { toggle() }
        row1.addView(toggleBtn, rowParams(8))
        val r1 = LinearLayout.LayoutParams(MATCH, WRAP)
        r1.topMargin = px(8)
        p.addView(row1, r1)

        // Строка 2: размер
        val row2 = LinearLayout(svc)
        row2.orientation = LinearLayout.HORIZONTAL
        row2.gravity = Gravity.CENTER_VERTICAL
        seek = SeekBar(svc)
        seek.max = 250
        seek.progressTintList = ColorStateList.valueOf(Ui.ACCENT)
        seek.thumbTintList = ColorStateList.valueOf(Ui.ACCENT)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val c = board.selected ?: return
                prof.c[c]?.s = 0.5f + progress / 100f
                board.invalidate()
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        row2.addView(seek, weightParams())
        row2.addView(Ui.btn(svc, "Все −", Ui.CARD2, Ui.TEXT, d, 10) { scaleAll(0.9f) }, rowParams(6))
        row2.addView(Ui.btn(svc, "Все +", Ui.CARD2, Ui.TEXT, d, 10) { scaleAll(1.1f) }, rowParams(6))
        val r2 = LinearLayout.LayoutParams(MATCH, WRAP)
        r2.topMargin = px(6)
        p.addView(row2, r2)

        // Дополнительные настройки (раскрываются кнопкой «Ещё»)
        extra = LinearLayout(svc)
        extra.orientation = LinearLayout.VERTICAL
        extra.visibility = View.GONE
        val rm = LinearLayout(svc)
        rm.orientation = LinearLayout.HORIZONTAL
        rm.gravity = Gravity.CENTER_VERTICAL
        val ml = TextView(svc)
        ml.text = "Режим"
        ml.textSize = 13f
        ml.setTextColor(Ui.TEXT)
        rm.addView(ml, weightParams())
        modeBtn = Ui.btn(svc, "Удержание", Ui.CARD2, Ui.ACCENT, d, 12) { cycleMode() }
        rm.addView(modeBtn, rowParams(8))
        val rmp = LinearLayout.LayoutParams(MATCH, WRAP)
        rmp.topMargin = px(8)
        extra.addView(rm, rmp)
        val rr = LinearLayout(svc)
        rr.orientation = LinearLayout.HORIZONTAL
        rr.gravity = Gravity.CENTER_VERTICAL
        val rl = TextView(svc)
        rl.text = "Нажимает точку"
        rl.textSize = 13f
        rl.setTextColor(Ui.TEXT)
        rr.addView(rl, weightParams())
        mapBtn = Ui.btn(svc, "своя", Ui.CARD2, Ui.ACCENT, d, 12) { cycleMap() }
        rr.addView(mapBtn, rowParams(8))
        val rrp = LinearLayout.LayoutParams(MATCH, WRAP)
        rrp.topMargin = px(8)
        extra.addView(rr, rrp)
        deadSeek = addSlider(extra, "Мёртвая зона стиков", 35) { v -> prof.dead = 0.05f + v / 100f }
        sensSeek = addSlider(extra, "Чувствительность стиков", 150) { v -> prof.sens = 0.5f + v / 100f }
        alphaSeek = addSlider(extra, "Прозрачность кружков", 80) { v ->
            prof.alpha = 0.2f + v / 100f
            board.invalidate()
        }
        hideBtn = Ui.btn(svc, "Скрыть кружки", Ui.CARD2, Ui.TEXT, d, 12) {
            board.hidden = !board.hidden
            hideBtn.text = if (board.hidden) "Показать кружки" else "Скрыть кружки"
            board.invalidate()
        }
        val hp = LinearLayout.LayoutParams(MATCH, WRAP)
        hp.topMargin = px(8)
        extra.addView(hideBtn, hp)
        val flip = Ui.btn(svc, "⇅  Перенести панель вверх / вниз", Ui.CARD2, Ui.TEXT, d, 12) { flipPanel() }
        val fp = LinearLayout.LayoutParams(MATCH, WRAP)
        fp.topMargin = px(8)
        extra.addView(flip, fp)
        val ep = LinearLayout.LayoutParams(MATCH, WRAP)
        ep.topMargin = px(4)
        p.addView(extra, ep)

        // Строка 3: действия
        val row3 = LinearLayout(svc)
        row3.orientation = LinearLayout.HORIZONTAL
        row3.addView(Ui.btn(svc, "Сохранить", Ui.ACCENT, Ui.ON_ACCENT, d, 8) { save() }, weightParams())
        row3.addView(Ui.btn(svc, "Сбросить", Ui.CARD2, Ui.TEXT, d, 8) { reset() }, weightParams(6))
        row3.addView(Ui.btn(svc, "Отмена", Ui.CARD2, Ui.TEXT, d, 8) { close() }, weightParams(6))
        row3.addView(Ui.btn(svc, "Ещё", Ui.CARD2, Ui.TEXT, d, 10) {
            extra.visibility = if (extra.visibility == View.GONE) View.VISIBLE else View.GONE
        }, rowParams(6))
        val r3 = LinearLayout.LayoutParams(MATCH, WRAP)
        r3.topMargin = px(10)
        p.addView(row3, r3)

        val sw = svc.resources.displayMetrics.widthPixels
        val pw = min(sw, px(520))
        val lp = FrameLayout.LayoutParams(pw, WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        lp.setMargins(0, px(8), 0, px(8))
        root.addView(p, lp)

        val wlp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28) {
            wlp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        try {
            wm.addView(root, wlp)
            added = true
        } catch (e: Exception) {
            done()
            return
        }
        refresh()
    }

    private fun addSlider(parent: LinearLayout, title: String, max: Int, onChange: (Int) -> Unit): SeekBar {
        val t = TextView(svc)
        t.text = title
        t.textSize = 12f
        t.setTextColor(Ui.MUTED)
        val tp = LinearLayout.LayoutParams(MATCH, WRAP)
        tp.topMargin = px(8)
        parent.addView(t, tp)
        val sb = SeekBar(svc)
        sb.max = max
        sb.progressTintList = ColorStateList.valueOf(Ui.ACCENT)
        sb.thumbTintList = ColorStateList.valueOf(Ui.ACCENT)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) onChange(progress)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        parent.addView(sb, LinearLayout.LayoutParams(MATCH, WRAP))
        return sb
    }

    private fun cycleMode() {
        val c = board.selected ?: return
        val g = prof.c[c] ?: return
        g.m = (g.m + 1) % (if (c.stick) stickModes.size else modes.size)
        refresh()
    }

    private fun cycleMap() {
        val c = board.selected ?: return
        if (c.stick) return
        val g = prof.c[c] ?: return
        val list = Control.values().filter { !it.stick && it != c }
        val idx = if (g.r < 0) -1 else list.indexOfFirst { it.ordinal == g.r }
        val next = idx + 1
        g.r = if (next >= list.size) -1 else list[next].ordinal
        refresh()
    }

    private fun refresh() {
        deadSeek.progress = ((prof.dead - 0.05f) * 100f).toInt().coerceIn(0, 35)
        alphaSeek.progress = ((prof.alpha - 0.2f) * 100f).toInt().coerceIn(0, 80)
        sensSeek.progress = ((prof.sens - 0.5f) * 100f).toInt().coerceIn(0, 150)
        val c = board.selected
        if (c == null) {
            nameView.text = "Ничего не выбрано"
            toggleBtn.alpha = 0.4f
            modeBtn.alpha = 0.4f
            mapBtn.alpha = 0.4f
            seek.isEnabled = false
            return
        }
        val g = prof.c[c] ?: return
        nameView.text = c.title
        toggleBtn.text = if (g.on) "Выключить" else "Включить"
        toggleBtn.alpha = 1f
        modeBtn.text = if (c.stick) stickModes[g.m.coerceIn(0, 2)] else modes[g.m.coerceIn(0, 3)]
        modeBtn.alpha = 1f
        mapBtn.text = if (g.r < 0) "своя" else Control.values()[g.r].label
        mapBtn.alpha = if (c.stick) 0.4f else 1f
        seek.isEnabled = true
        seek.progress = ((g.s - 0.5f) * 100f).toInt().coerceIn(0, 250)
    }

    private fun toggle() {
        val c = board.selected ?: return
        val g = prof.c[c] ?: return
        g.on = !g.on
        refresh()
        board.invalidate()
    }

    private fun scaleAll(k: Float) {
        for (g in prof.c.values) g.s = (g.s * k).coerceIn(0.5f, 3f)
        refresh()
        board.invalidate()
    }

    private fun reset() {
        for ((k, g) in prof.c) {
            g.x = k.dx
            g.y = k.dy
            g.on = k.on
            g.s = 1f
            g.m = 0
            g.r = -1
        }
        prof.alpha = 1f
        prof.dead = 0.1f
        prof.sens = 1f
        refresh()
        board.invalidate()
    }

    private fun flipPanel() {
        panelTop = !panelTop
        val lp = panel.layoutParams as FrameLayout.LayoutParams
        lp.gravity = (if (panelTop) Gravity.TOP else Gravity.BOTTOM) or Gravity.CENTER_HORIZONTAL
        panel.layoutParams = lp
    }

    private fun save() {
        Store.save(pkg, prof)
        close()
    }

    fun close() {
        if (added) {
            try {
                wm.removeView(root)
            } catch (e: Exception) {
            }
            added = false
            done()
        }
    }
}
